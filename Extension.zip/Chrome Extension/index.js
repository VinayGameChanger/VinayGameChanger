let data = document.querySelector('.data');
let textBox = document.querySelector('#text-box')
console.log(window);

// save button
function saveFnc() {
  if (textBox.value == '') {

  } else {
    let element = document.createElement('p')
    let element2 = document.createElement('a')
    element2.textContent = textBox.value;
    element2.setAttribute('href', 'https://' + textBox.value)
    element2.setAttribute('target', '_blank')
    element.append(element2)
    data.append(element)
    textBox.value = '';
  }

}

function saveTab() {
  let element = document.createElement('p')
  let element2 = document.createElement('a')
  element2.setAttribute('href', window.location.href)
  element2.setAttribute('target', '_blank')
  element2.textContent = window.location.href;

  element.append(element2)
  data.append(element)
}

function deleteAll() {
  data.innerHTML = '';
}